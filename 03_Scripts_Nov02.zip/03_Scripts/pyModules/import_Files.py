import os, sys, csv, subprocess, time, xlrd, xlwt, csv

from pyModules.variables import *
from postGIS import *
from pg_queries import *


def convert_XLS_CSV (inXLS, outCSV, inSheet):

    # convert xls to csv
    wb = xlrd.open_workbook(inXLS, 'utf-8')
    sh = wb.sheet_by_name(inSheet)
    csv_File = open(outCSV, 'wb')
    wr = csv.writer(csv_File, quoting=csv.QUOTE_ALL)

    for rownum in xrange(sh.nrows):
        wr.writerow    ([unicode(val).encode('utf8') for val in sh.row_values(rownum)])

    csv_File.close()

def Step_01_import_Vectors (cursor):


    # shape =  LULC['corine_bbox']
    for shape in [ ADM['bbox_3035'], ADM['communes'], LULC['corine_bbox']  ]:

        import_SHP (cursor=cursor, shapefile=shape.inFile_Full, table=shape.name)


def Step_02_clip_Corine (cursor, old_LULC, new_LULC, clip_table):

    attribute = "code_12"

    clip_Corine = """
        {new_LULC} AS
        (SELECT ST_Intersection (a.geom, b.geom) AS geom, a.{attribute}
        FROM {old_LULC} AS a, {clip_table} AS b
        WHERE ST_Intersects(a.geom, b.geom));
    """.format (
            new_LULC = create_table(new_LULC),
            old_LULC = old_LULC,
            attribute = attribute,
            clip_table = clip_table
        )

    execute_Query (cursor, clip_Corine)


def Step_03_join_Legend (cursor, lulc, legend):

    import_CSV_PostGIS (cursor=cursor, table=legend.name, csv=legend.inFile_Full, sep=';')

    lulc_columns= (
        add_column (table = lulc, column = 'label character varying (255)') +
        add_column (table = lulc, column = 'grass_color character varying (100)') +
        add_column (table = lulc, column = 'qgis_color character varying (100)')
    )

    lulc_join=  """
        UPDATE {lulc}
        SET label = b.label3,
            grass_color = b.color,
            qgis_color = replace(b.color , ':', ',')
        FROM {legend} b
        WHERE code_12 = b.code::text;
    """.format (
            lulc = lulc,
            legend = legend.name
        )

    execute_Query (cursor, lulc_columns)
    execute_Query (cursor, lulc_join)


def Step_03b_extract_crop_Areas (cursor):


    for key in ['corine_crop', 'corine_No_crop']:

        if key == 'corine_No_crop':
            criteria  = " NOT "
        else:
            criteria  = " "

        crop = sql_create_table (
            table = LULC[key].name,
            select = '*',
            from_ = LULC['corine_adm'].name,
            where = criteria + "(code_12 = '243' or code_12 = '211' or code_12 = '231' or code_12 = '321' or code_12 = '242')"
            )

        execute_Query (cursor, crop)


def Step_04_import_Farms (cursor, table):

    for key in FARM:

        print ""

        csv_file = FARM[key].outFile + '.csv'

        convert_XLS_CSV (inXLS=FARM[key].inFile_Full, outCSV=csv_file, inSheet=FARM[key].outFile)

        import_CSV_PostGIS (cursor=cursor, table=FARM[key].name, csv=csv_file, sep=',')

        set_Primary_Key (cursor=cursor, table=FARM[key].name, primary_key='farm_id')

        os.remove (csv_file)
