# -*- coding: utf-8 -*-
"""@author: fernando fahl"""
import os, sys, csv, subprocess, time

from pyModules.variables import *

import pyModules.import_Files as FILES
import pyModules.postGIS as PG
import pyModules.OSM as OSM



if __name__ == "__main__":

    print ""

    #==============================================================================
    #           PostGIS Database
    #==============================================================================

    # PG.create_DB ()
    cursor_2 = PG.connect_PostGIS ()

    #==============================================================================
    #           ADM and LULC
    #==============================================================================

    # FILES.Step_01_import_Vectors (cursor)
    # FILES.Step_02_clip_Corine(cursor=cursor, old_LULC=LULC['corine_bbox'].name , new_LULC=LULC['corine_adm'].name , clip_table=ADM['communes'].name )
    # FILES.Step_03_join_Legend (cursor=cursor, lulc=LULC['corine_adm'].name, legend=LULC['legend'])
    # FILES.Step_03b_extract_crop_Areas (cursor=cursor)

    #==============================================================================
    #           FARMS
    #==============================================================================

    # FILES.Step_04_import_Farms (cursor=cursor, table=FARM)

    #==============================================================================
    #           OSM Import
    #==============================================================================

    # OSM.Step_01_download_OSM (raw=OSM_raw['austria'], osm=OSM_Files['pbf'])
    # OSM.Step_02_import_PostGIS (osm=OSM_Files['pbf'], cache=True, limit_AOI=True)
    # OSM.Step_03_reproject_Tables (cursor=cursor, tables=OSM_tables)

    #==============================================================================
    #           OSM queries
    #==============================================================================

    # OSM.Step_04_create_Farm_Roads ()
    # OSM.Step_05_create_Target_Points ()
    # OSM.Step_06_clean_Target_Points ()
    # OSM.Step_07_rank_Target_Points ()
    # OSM.Step_08_create_Road_Topology ()
    OSM.Step_09_update_Topology ()
