from variables import *
import postGIS as PG



def create_table (table):
    return "DROP TABLE IF EXISTS {0}; CREATE TABLE {0}".format (table)

def select_data (select):
    return "SELECT {0}".format (select)

def from_table (from_):
    return "FROM {0}".format (from_)

def filter_table (where):
    return "WHERE {0}".format (where)

def update_column (table, column, value):
    return "UPDATE {0} a SET {1} = {2};".format (table, column, value)


def create_sequence (sequence):
    sql = "DROP SEQUENCE IF EXISTS {0}; CREATE SEQUENCE {0};".format (sequence)
    PG.execute_Query (sql, "")

def restart_sequence (cursor, sequence):
    sql = "ALTER SEQUENCE {0} RESTART WITH 1;".format (sequence)
    PG.execute_Query (sql, "")

def drop_table (table):
    sql = "DROP TABLE IF EXISTS {0};".format (table)
    PG.execute_Query (sql, "")

def drop_key (table):
    sql = "ALTER TABLE {0} DROP CONSTRAINT {0}_pkey;".format (table)
    PG.execute_Query (sql, "")

def add_column (table, column):
    sql = "ALTER TABLE  {0} ADD COLUMN IF NOT EXISTS {1};".format (table, column)
    PG.execute_Query (sql, table)

def drop_column (table, column):
    sql = "ALTER TABLE {0} DROP COLUMN IF EXISTS {1};".format (table, column)
    PG.execute_Query (sql, "")

def pgr_topology (table, tolerance, id):
    sql =  "SELECT pgr_createTopology(\'{0}\', {1}, 'geom', '{2}');".format (table, tolerance, id)
    PG.execute_Query (sql, table)

def pgr_nodeNetwork (table, tolerance, id):
    sql =  "SELECT pgr_nodeNetwork(\'{0}\', {1}, '{2}', 'geom');".format (table, tolerance, id)
    PG.execute_Query (sql, table)

def pgr_analyzeGraph (table, tolerance, id):
    sql =  "SELECT pgr_analyzeGraph(\'{0}\', {1}, 'geom', '{2}');".format (table, tolerance, id)
    PG.execute_Query (sql, "")

def sql_custom (table, sql):
    PG.execute_Query (sql, table)

def sql_update_table (table, column, value, from_, where):

    sql = "{update} {from_} {where};".format (
        update = update_column (table, column, value),
        from_ = from_table (from_),
        where = filter_table (where)
    )

    PG.execute_Query (sql, table)

def sql_create_table (table, select, from_, where):

    if from_ == '':

        sql = "{create} AS {select};".format (
            create = create_table (table),
            select = select_data (select)
        )

    elif where == '':

        sql = "{create} AS {select} {from_};".format (
            create = create_table (table),
            select = select_data (select),
            from_ = from_table (from_)
        )

    else:

        sql = "{create} AS {select} {from_} {where};".format (
            create = create_table (table),
            select = select_data (select),
            from_ = from_table (from_),
            where = filter_table (where)
        )

    PG.execute_Query (sql, table)

def sql_create_table_with (table, with_, where):

    if where == '':

        sql = "{create} AS {with_};".format (
            create = create_table (table),
            with_ = with_
        )

    else:

        sql = "{create} AS {with_} {where};".format (
            create = create_table (table),
            with_ = with_,
            where = where

        )

    PG.execute_Query (sql, table)
