from variables import *
from pyModules.postGIS import *


#==============================================================================
#   there are 3 ways to extract and upload OSM data into PostGIS
#   see:
#       http://mike.teczno.com/notes/osm-and-postgres.html
#
#   It was choosen the imposm due to the fact it creates tables according to specific tags.
#   Functions based on the other libraries were created but not used here
#==============================================================================


def Step_01_download_OSM (raw, osm):

    os.chdir(osm.inDir)

    url = raw.url

    print "\n{url}\n".format(url=url)

    f = urllib2.urlopen(url)
    with open(raw.osm_name, "wb") as code:
        code.write(f.read())

def Step_02_import_PostGIS (osm, cache, limit_AOI):

    osm_file = osm.inFile_Full
    mapping = yml_folder + "/mapping.yml"

    create_cache = "{command} {mapping} {cache} {read}".format(
        command = "imposm3 import -overwritecache",
        mapping = "-mapping " + mapping,
        read = "-read "  + osm_file,
        cache = "-cachedir " + imposm3_cache)

    if limit_AOI:
        restrict_AOI = "-limitto {file} -limittocachebuffer {buffer} ".format(
            file=bbox_OSM['JSON'].inFile_Full,
            buffer = 10000)
    else:
        restrict_AOI = ""


    # ___________________ run Imposm
    outfile = "-write -connection postgis://{user}:{pwd}@{host}:{port}/{database}".format(
        user = db_PostGIS['user'],
        pwd = db_PostGIS['pwd'],
        host = db_PostGIS['host'],
        port = db_PostGIS['port'],
        database = db_PostGIS['dbname']
    )


    load_postgis = "{command} {mapping} {cache} {limitto} {outfile} ".format(
        command = "imposm3 import -optimize -deployproduction",
        mapping = "-mapping " + mapping,
        cache = "-cachedir " + imposm3_cache,
        limitto = restrict_AOI,
        outfile = outfile)

    if cache:
        print "\n__________________ creating CACHE ______________________\n"
        subprocess.call(create_cache, shell=True)

    print "\n__________________ loading OSM ______________________\n"
    subprocess.call(load_postgis, shell=True)

    # test_DB (db=db, table='osm_power')

def Step_03_reproject_Tables (cursor, tables):

    reproject_OSM (cursor=cursor, tables=tables)

def Step_04_create_Farm_Roads ():

    # ______________ create main roads
    sql_create_table (
        table = SQL_roads['roads_main'].name,
        select = '*',
        from_ = SQL_roads['roads_main'].from_,
        where = "value = 'primary' OR value = 'secondary' OR value = 'tertiary'"
    )

    add_column (table = SQL_target['site_clean'].name, column = 'id_road SERIAL PRIMARY KEY')

def Step_05_create_Target_Points ():

    # ______________ create points over the roads every 500 m
    sql_points = """
        (WITH
            line AS
                (SELECT (ST_Dump(geom)).geom AS geom FROM {table}),
            linemeasure AS
                (SELECT
                    ST_AddMeasure(line.geom, 0, ST_Length(line.geom)) AS linem,
                    generate_series(0, ST_Length(line.geom)::int, {distance}) AS {id}
                FROM line),
            geometries AS (
                SELECT
                    {id},
                    (ST_Dump(ST_GeometryN(ST_LocateAlong(linem, {id}), 1))).geom AS geom
                FROM linemeasure)
        SELECT
            {id},
            ST_SetSRID(ST_MakePoint(ST_X(geom), ST_Y(geom)), {proj}) AS geom
        FROM geometries)
    """.format (
            id = 'id_target',
            table = SQL_roads['roads_main'].name,
            proj = db_PostGIS['proj'],
            distance = SQL_target_distance
            )

    sql_create_table_with (
        table = SQL_target['site_targets'].name,
        with_ = sql_points,
        where = ""
        )

    drop_column (table = SQL_target['site_targets'].name, column = 'id_target')
    add_column (table = SQL_target['site_targets'].name, column = 'id_target SERIAL PRIMARY KEY')


def Step_06_clean_Target_Points ():

    # ______________ remove points outside comunnes
    sql_create_table (
        table = SQL_target['site_clean'].name,
        select = "a.*",
        from_ = SQL_target['site_targets'].name + " a, " + ADM['communes'].name + " b",
        where = "ST_intersects (a.geom, b.geom)"
    )

    # ______________ clean points based on proximity
    sql_clean= """
        DELETE FROM {table} a
        WHERE EXISTS (
            SELECT {select}
            FROM {table} b
            WHERE  a.{id} < b.{id}
            AND st_dwithin(a.geom, b.geom, {distance})
        );
    """.format (
            table = SQL_target['site_clean'].name,
            select = '1',
            id = 'id_target',
            distance = (SQL_target_distance / 2)
            )

    sql_custom (table=SQL_target['site_clean'].name, sql=sql_clean)

    drop_column (table = SQL_target['site_clean'].name, column = 'id_target')
    add_column (table = SQL_target['site_clean'].name, column = 'id_target SERIAL PRIMARY KEY')



def Step_07_rank_Target_Points ():

    print ""

    add_column (table = SQL_target['site_clean'].name, column = 'land_code VARCHAR')
    add_column (table = SQL_target['site_clean'].name, column = 'land_label VARCHAR')
    add_column (table = SQL_target['site_clean'].name, column = 'land_color VARCHAR')
    add_column (table = SQL_target['site_clean'].name, column = 'land_rank integer')


    sql_landcover = """
        UPDATE {table} a
        SET land_code = b.code_12,
            land_label = b.label,
            land_color = b.qgis_color
        FROM {lulc} b
        WHERE ST_intersects (a.geom, b.geom);
    """.format (
            table = SQL_target['site_clean'].name,
            lulc = LULC['corine_adm'].name
            )

    sql_rank = """
        UPDATE {table}
        SET {column} =
        CASE {criteria}
            WHEN '111' THEN 13
            WHEN '112' THEN 12
            WHEN '121' THEN 11
            WHEN '122' THEN 10
            WHEN '131' THEN 9
            WHEN '211' THEN 8
            WHEN '231' THEN 7
            WHEN '242' THEN 6
            WHEN '243' THEN 5
            WHEN '311' THEN 4
            WHEN '312' THEN 3
            WHEN '313' THEN 2
            WHEN '511' THEN 1
        ELSE 0
        END;""".format (
            table = SQL_target['site_clean'].name,
            column = 'land_rank',
            criteria = 'land_code'
            )


    sql_custom (table=SQL_target['site_clean'].name, sql=sql_landcover)
    sql_custom (table=SQL_target['site_clean'].name, sql=sql_rank)


def Step_08_create_Road_Topology ():

    # ______________ drop tables
    drop_table (table = SQL_roads['roads_main_vertices_pgr'].name)
    drop_table (table = SQL_roads['roads_main_noded'].name)

    # ______________ add columns for topology analysis
    drop_column (table = SQL_roads['roads_main'].name, column = 'id')
    add_column (table = SQL_roads['roads_main'].name, column = 'id_road SERIAL PRIMARY KEY')
    add_column (table = SQL_roads['roads_main'].name, column = 'source INT4')
    add_column (table = SQL_roads['roads_main'].name, column = 'target INT4')

    # ______________ create topology
    pgr_topology (table=SQL_roads['roads_main'].name, tolerance='0.001', id='id_road')
    pgr_nodeNetwork (table=SQL_roads['roads_main'].name, tolerance='0.001', id='id_road')
    pgr_topology (table=SQL_roads['roads_main_noded'].name, tolerance='0.001', id='id')


    pgr_analyzeGraph (table=SQL_roads['roads_main'].name, tolerance='0.001', id='id_road')
    pgr_analyzeGraph (table=SQL_roads['roads_main_noded'].name, tolerance='0.001', id='id')



def Step_09_update_Topology ():

    # add_column (table = SQL_roads['roads_main_noded'].name, column = 'name VARCHAR')
    # add_column (table = SQL_roads['roads_main_noded'].name, column = 'type VARCHAR')
    # add_column (table = SQL_roads['roads_main_noded'].name, column = 'oneway VARCHAR')
    # add_column (table = SQL_roads['roads_main_noded'].name, column = 'surface VARCHAR')
    # add_column (table = SQL_roads['roads_main_noded'].name, column = 'distance FLOAT8')
    # add_column (table = SQL_roads['roads_main_noded'].name, column = 'time FLOAT8')

    sql_attr= """
        UPDATE {table} a
        SET name = b.name,
            type = b.value,
            oneway = b.oneway,
            surface = b.surface
        FROM {edge} b
        WHERE a.id = b.id_road;
    """.format (
            table = SQL_roads['roads_main_noded'].name,
            edge = SQL_roads['roads_main'].name
            )

    sql_distancer= """
        UPDATE {table}
        SET {column} = ST_Length(geom) / 1000;
    """.format (
            table = SQL_roads['roads_main_noded'].name,
            column = 'distance'
            )

    sql_time= """
        UPDATE {table}
        SET {column} =
        CASE {criteria}
            WHEN 'steps' THEN -1
            WHEN 'path' THEN -1
            WHEN 'footway' THEN -1
            WHEN 'cycleway' THEN -1
            WHEN 'proposed' THEN -1
            WHEN 'construction' THEN -1
            WHEN 'raceway' THEN distance / 100
            WHEN 'motorway' THEN distance / 70
            WHEN 'motorway_link' THEN distance / 70
            WHEN 'trunk' THEN distance / 60
            WHEN 'trunk_link' THEN distance / 60
            WHEN 'primary' THEN distance / 55
            WHEN 'primary_link' THEN distance / 55
            WHEN 'secondary' THEN distance / 45
            WHEN 'secondary_link' THEN distance / 45
            WHEN 'tertiary' THEN distance / 45
            WHEN 'tertiary_link' THEN distance / 40
            WHEN 'unclassified' THEN distance / 35
            WHEN 'residential' THEN distance / 30
            WHEN 'living_street' THEN distance / 30
            WHEN 'service' THEN distance / 30
            WHEN 'track' THEN distance / 20
            ELSE distance / 20
        END;""".format (
            table = SQL_roads['roads_main_noded'].name,
            column = 'time',
            criteria = 'type'
            )

    sql_custom (table=SQL_roads['roads_main_noded'].name, sql=sql_attr)
    sql_custom (table=SQL_roads['roads_main_noded'].name, sql=sql_distancer)
    sql_custom (table=SQL_roads['roads_main_noded'].name, sql=sql_time)


#
# UPDATE farm_roads_edges_noded SET
#   time =
#   CASE type
#     WHEN 'steps' THEN -1
#     WHEN 'path' THEN -1
#     WHEN 'footway' THEN -1
#     WHEN 'cycleway' THEN -1
#     WHEN 'proposed' THEN -1
#     WHEN 'construction' THEN -1
#     WHEN 'raceway' THEN distance / 100
#     WHEN 'motorway' THEN distance / 70
#     WHEN 'motorway_link' THEN distance / 70
#     WHEN 'trunk' THEN distance / 60
#     WHEN 'trunk_link' THEN distance / 60
#     WHEN 'primary' THEN distance / 55
#     WHEN 'primary_link' THEN distance / 55
#     WHEN 'secondary' THEN distance / 45
#     WHEN 'secondary_link' THEN distance / 45
#     WHEN 'tertiary' THEN distance / 45
#     WHEN 'tertiary_link' THEN distance / 40
#     WHEN 'unclassified' THEN distance / 35
#     WHEN 'residential' THEN distance / 30
#     WHEN 'living_street' THEN distance / 30
#     WHEN 'service' THEN distance / 30
#     WHEN 'track' THEN distance / 20
#     ELSE distance / 20
#   END;
#
#
#   UPDATE farm_roads_edges_noded SET
#   distance =
#   CASE type
#     WHEN 'steps' THEN -1
#     WHEN 'path' THEN -1
#     WHEN 'footway' THEN -1
#     WHEN 'cycleway' THEN -1
#     WHEN 'proposed' THEN -1
#     WHEN 'construction' THEN -1
#     ELSE distance
#   END;

# SELECT row_number() over () AS id,
#   ST_NumGeometries(gc),
#   gc AS geom_collection,
#   ST_Centroid(gc) AS centroid,
#   ST_MinimumBoundingCircle(gc) AS circle,
#   sqrt(ST_Area(ST_MinimumBoundingCircle(gc)) / pi()) AS radius
# FROM (
#   SELECT unnest(ST_ClusterWithin(geom, 100)) gc FROM farm_buildings_points) f;
#


    # # ______________ drop tables
    # drop_road_tables = (
    #     drop_table (table = SQL_roads['roads_main'].name) +
    #     drop_table (table = SQL_roads['roads_main_vertices_pgr'].name) +
    #     drop_table (table = SQL_roads['roads_main_noded'].name)
    #     )

    #
    # roads_main_add_columns = (
    #     drop_column (table = SQL_tables['roads_main'].name, column = 'id') +
    #     add_column (table = SQL_tables['roads_main'].name, column = 'id SERIAL PRIMARY KEY') +
    #     add_column (table = SQL_tables['roads_main'].name, column = 'source INT4') +
    #     add_column (table = SQL_tables['roads_main'].name, column = 'target INT4')
    #     )
    #
    # roads_main_topology = (
    #     create_topology (table = SQL_tables['roads_main'].name, tolerance=0.001) +
    #     create_nodeNetwork (table = SQL_tables['roads_main'].name , tolerance=0.001) +
    #     create_topology (table = SQL_tables['roads_main_noded'].name, tolerance=0.001)
    #     )
    #
    # roads_edge_add_columns = (
    #     add_column (table = SQL_tables['roads_main_noded'].name, column = 'name VARCHAR') +
    #     add_column (table = SQL_tables['roads_main_noded'].name, column = 'type VARCHAR') +
    #     add_column (table = SQL_tables['roads_main_noded'].name, column = 'oneway VARCHAR') +
    #     add_column (table = SQL_tables['roads_main_noded'].name, column = 'surface VARCHAR') +
    #     add_column (table = SQL_tables['roads_main_noded'].name, column = 'distance FLOAT8') +
    #     add_column (table = SQL_tables['roads_main_noded'].name, column = 'time FLOAT8')
    #     )
    #
    # roads_edge_update_attr = """
    #     UPDATE {table1} AS new
    #     SET name = old.name, type = old.value, oneway = old.oneway, surface = old.surface
    #     FROM {table2} AS old
    #     WHERE new.old_id = old.id;
    # """.format (
    #         table1 = SQL_tables['roads_main_noded'].name,
    #         table2 = SQL_tables['roads_main'].name
    # )
    #
    # time_condition = """
    #     CASE type
    #         WHEN 'steps' THEN -1
    #         WHEN 'path' THEN -1
    #         WHEN 'footway' THEN -1
    #         WHEN 'cycleway' THEN -1
    #         WHEN 'proposed' THEN -1
    #         WHEN 'construction' THEN -1
    #         WHEN 'raceway' THEN distance / 100
    #         WHEN 'motorway' THEN distance / 70
    #         WHEN 'motorway_link' THEN distance / 70
    #         WHEN 'trunk' THEN distance / 60
    #         WHEN 'trunk_link' THEN distance / 60
    #         WHEN 'primary' THEN distance / 55
    #         WHEN 'primary_link' THEN distance / 55
    #         WHEN 'secondary' THEN distance / 45
    #         WHEN 'secondary_link' THEN distance / 45
    #         WHEN 'tertiary' THEN distance / 45
    #         WHEN 'tertiary_link' THEN distance / 40
    #         WHEN 'unclassified' THEN distance / 35
    #         WHEN 'residential' THEN distance / 30
    #         WHEN 'living_street' THEN distance / 30
    #         WHEN 'service' THEN distance / 30
    #         WHEN 'track' THEN distance / 20
    #         ELSE distance / 20
    #     END
    # """
    #
    # distance_condition  = """
    #     CASE type
    #         WHEN 'steps' THEN -1
    #         WHEN 'path' THEN -1
    #         WHEN 'footway' THEN -1
    #         WHEN 'cycleway' THEN -1
    #         WHEN 'proposed' THEN -1
    #         WHEN 'construction' THEN -1
    #         ELSE distance
    #     END
    # """
    #
    # roads_edge_distance  = (
    #     update_column (table=SQL_tables['roads_main_noded'].name, column='distance', value='ST_Length(ST_Transform(geom, 4326)::geography) / 1000') +
    #     update_column (table=SQL_tables['roads_main_noded'].name, column='time', value=time_condition) +
    #     update_column (table=SQL_tables['roads_main_noded'].name, column='distance', value=distance_condition)
    #     )
